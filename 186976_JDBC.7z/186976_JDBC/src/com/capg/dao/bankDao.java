package com.capg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capg.bean.BankBean;
import com.capg.bean.BankTransaction;

public class bankDao implements bankDaoImpl {

	Connection connection = null;
	PreparedStatement pstmt = null;
	ResultSet result = null;
	BankBean bank = new BankBean();

	@Override
	public boolean checkAccount(long accNo) throws ClassNotFoundException, SQLException {

		boolean res = false;

		String query = "Select * from bank where accountno = ?";
		connection  = bankDB.getConnection();
		pstmt =connection .prepareStatement(query);
		pstmt.setLong(1, accNo);
		result = pstmt.executeQuery();

		if (result.next()) {
			res = false;
		} else {
			res = true;
		}
		return res;
	}

	@Override
	public void InsertData(long accNo, BankBean bean) throws ClassNotFoundException, SQLException {

		connection  = bankDB.getConnection();
		pstmt = connection .prepareStatement("Insert into bank values (?,?,?,?,?,?)");

		pstmt.setString(1, bean.getName());
		pstmt.setLong(2, bean.getAccNo());
		pstmt.setLong(3, bean.getPin());
		pstmt.setString(4, bean.getAdd());
		pstmt.setString(5, bean.getPhone());
		pstmt.setInt(6, bean.getBalance());

		int r =pstmt.executeUpdate();

		if (r == 0) {
			System.out.println("Not inserted");
		} else {
			System.out.println("Value inserted");
		}
	}

	@Override
	public void updateData(BankBean bean) throws ClassNotFoundException, SQLException {

		connection  = bankDB.getConnection();
		pstmt = connection .prepareStatement("Update bank set balance = ? where accountno = ?");
		pstmt.setInt(1, bean.getBalance());
		pstmt.setLong(2, bean.getAccNo());

		int r = pstmt.executeUpdate();

		if (r == 0) {
			System.out.println("Cannot update");
		} else {
			System.out.println("Updated");
		}
	}

	@Override
	public BankBean getAccountDetails(long accNo) throws ClassNotFoundException, SQLException {
		boolean res = false;

		String query = "Select * from bank where accountno = ?";
		connection  = bankDB.getConnection();
		pstmt = connection.prepareStatement(query);
		pstmt.setLong(1, accNo);
		result =pstmt.executeQuery();

		if (result.next()) {
			bank.setName(result.getString(1));
			bank.setAccNo(result.getLong(2));
			bank.setPin(result.getInt(3));
			bank.setAdd(result.getString(4));
			bank.setPhone(result.getString(5));
			bank.setBalance(result.getInt(6));
		} else {
			bank = null;
		}
		return bank;
	}

	@Override
	public void setTransactions(BankTransaction trans) throws ClassNotFoundException, SQLException {

		String query = "Insert into transactions values (?,?,?,?)";
		connection = bankDB.getConnection();
		pstmt= connection .prepareStatement(query);
		pstmt.setString(1, trans.getType());
		pstmt.setLong(2, trans.getAccNo());
		pstmt.setInt(3, trans.getAmount());
		pstmt.setInt(4, trans.getTransaction_id());

		int res = pstmt.executeUpdate();

		if (res == 0) {
			System.out.println("Data is not inserted");
		} else {
			System.out.println("Data is updated ");
		}

	}

	@Override
	public BankTransaction getTransactions(long actNum) throws ClassNotFoundException, SQLException {

		BankTransaction trans = new BankTransaction();
		String query = "Select * from transactions where accountno = ?";
		connection = bankDB.getConnection();
		pstmt = connection .prepareStatement(query);
		pstmt.setLong(1, actNum);

		result =pstmt.executeQuery();

		if (result.next()) {
			trans.setType(result.getString(1));
			trans.setAccNo(result.getLong(2));
			trans.setAmount(result.getInt(3));
			trans.setTransaction_id(result.getInt(4));
		}
		return trans;
	}

}
