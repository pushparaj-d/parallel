package com.capg.bean;

public class BankTransaction {

	private String type;
	private long actNum;
	private int amount;
	private int transaction_id;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public long getAccNo() {
		return actNum;
	}

	public void setAccNo(long actNum) {
		this.actNum = actNum;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getTransaction_id() {
		return transaction_id;
	}

	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}

}
