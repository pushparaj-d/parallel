package com.capg.exceptions;

public class accountAlreadyExistsException extends Exception {

	public accountAlreadyExistsException() {

	}

	@Override
	public String toString() {
		return "Account Already Exists";
	}

}
