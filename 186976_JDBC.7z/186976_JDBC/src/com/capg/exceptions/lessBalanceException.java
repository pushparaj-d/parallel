package com.capg.exceptions;

public class lessBalanceException extends Exception {

	public lessBalanceException() {

	}

	@Override
	public String toString() {
		return "Your account balance is too low..";
	}

}