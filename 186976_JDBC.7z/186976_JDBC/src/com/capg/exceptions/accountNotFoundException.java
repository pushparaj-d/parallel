package com.capg.exceptions;

public class accountNotFoundException extends Exception {

	public accountNotFoundException() {

	}

	public String toString() {

		return "Account Not Found . \nPlease enter a valid account number...!!!";
	}
}
