package com.capg.service;

import java.sql.SQLException;

import com.capg.bean.BankTransaction;
import com.capg.exceptions.*;

public interface bankServiceImpl {

	public boolean createAccount(String name, String add, long actNum, String phone, int pin, int bal)
			throws accountAlreadyExistsException, ClassNotFoundException, SQLException;

	public int showBalance(long actNum) throws accountNotFoundException, ClassNotFoundException, SQLException;

	public int deposit(long actNum, int deposit_amount)
			throws accountNotFoundException, ClassNotFoundException, SQLException;

	public int withdraw(long actNum, int withdraw_amount)
			throws accountNotFoundException, lessBalanceException, ClassNotFoundException, SQLException;

	public boolean transferfund(long actNum, long actNum1, int transfer_amount)
			throws accountNotFoundException, lessBalanceException, ClassNotFoundException, SQLException;

	public boolean validateBalance(long actNum, int amount)
			throws lessBalanceException, ClassNotFoundException, SQLException, accountNotFoundException;

	public String setTrans(long actNum) throws accountNotFoundException, ClassNotFoundException, SQLException;

	public void setTransactions(BankTransaction trans) throws ClassNotFoundException, SQLException;

	public BankTransaction getTransactions(long actNum) throws ClassNotFoundException, SQLException;

}
