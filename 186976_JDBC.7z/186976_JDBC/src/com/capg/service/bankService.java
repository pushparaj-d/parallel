package com.capg.service;

import java.sql.SQLException;

import com.capg.bean.BankBean;
import com.capg.bean.BankTransaction;
import com.capg.dao.bankDao;
import com.capg.dao.bankDaoImpl;
import com.capg.exceptions.*;

public class bankService implements bankServiceImpl {

	bankDaoImpl dao = (bankDaoImpl) new bankDao();
	BankBean bank = new BankBean();
	BankBean bank1 = new BankBean();

	boolean res;

	// to get the details if account exists or not and add account

	public boolean createAccount(String name, String add, long actNum, String phone, int pin, int bal)
			throws accountAlreadyExistsException, ClassNotFoundException, SQLException {

		BankBean bean = new BankBean();
		boolean res = false;
		res = dao.checkAccount(actNum);

		if (res) {
			bean.setAccNo(actNum);
			bean.setAdd(add);
			bean.setBalance(bal);
			bean.setName(name);
			bean.setPhone(phone);
			bean.setPin(pin);
			bean.setTrans("Account Created with Balance  : " + bal + "\n");

			dao.InsertData(actNum, bean);

			res = true;
		}

		else

		{
			res = false;
			throw new accountAlreadyExistsException();
		}
		return res;

	}

	// to show balance

	public int showBalance(long actNum) throws accountNotFoundException, ClassNotFoundException, SQLException {

		try {
			res = dao.checkAccount(actNum);
		}

		catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}

		int balance = 0;

		if (res) {
			throw new accountNotFoundException();
		} else {
			bank = dao.getAccountDetails(actNum);
			balance = bank.getBalance();
		}

		return balance;
	}

	// to deposit

	public int deposit(long actNum, int deposit_amount)
			throws accountNotFoundException, ClassNotFoundException, SQLException {

		int balance = 0;
		try {
			res = dao.checkAccount(actNum);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}

		if (res) {
			throw new accountNotFoundException();
		} else {
			bank = dao.getAccountDetails(actNum);
		}
		if (bank == null) {
			throw new accountNotFoundException();
		} else {

			balance = bank.setBalance(bank.getBalance() + deposit_amount);
			String s = bank.getTrans() + "Amount deposited :" + deposit_amount + "\n";
			bank.setTrans(s);
		
			dao.updateData(bank);
		}

		return balance;
	}

	// to withdraw

	public int withdraw(long actNum, int withdraw_amount)
			throws accountNotFoundException, lessBalanceException, ClassNotFoundException, SQLException {

		int balance = 0;
		try {
			res = dao.checkAccount(actNum);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}
		if (res) {
			throw new accountNotFoundException();
		} else {
			bank = dao.getAccountDetails(actNum);
			if (bank == null) {
				throw new accountNotFoundException();
			}
			if (bank.getBalance() > withdraw_amount) {
				balance = bank.setBalance(bank.getBalance() - withdraw_amount);
				String s = bank.getTrans() + "Amount withdrawn :" + withdraw_amount + "\n";
				bank.setTrans(s);
			} else {
				throw new lessBalanceException();
			}
			
			dao.updateData(bank);
		}

		return balance;
	}

	// to transfer fund

	public boolean transferfund(long actNum, long actNum1, int transfer_amount)
			throws accountNotFoundException, lessBalanceException, ClassNotFoundException, SQLException {

		res = dao.checkAccount(actNum);
		if (res) {
			throw new accountNotFoundException();
		} else {
			bank = dao.getAccountDetails(actNum);
			int balance = bank.getBalance();
			res = validateBalance(actNum, transfer_amount);
			if (res) {
				res = dao.checkAccount(actNum1);
				if (res) {
					throw new accountNotFoundException();
				} else {
					bank1 = dao.getAccountDetails(actNum1);
					int balance1 = bank1.getBalance();
					bank.setBalance(balance - transfer_amount);
					bank1.setBalance(balance1 + transfer_amount);
					dao.updateData(bank);
					dao.updateData(bank1);
				}
			} else {
				throw new lessBalanceException();

			}
		}
		return true;
	}

	// to validateBalance

	public boolean validateBalance(long actNum, int amount)
			throws lessBalanceException, accountNotFoundException, ClassNotFoundException, SQLException

	{

		res = dao.checkAccount(actNum);
		if (res) {
			throw new accountNotFoundException();
		} else {
			bank = dao.getAccountDetails(actNum);
			int balance = bank.getBalance();
			if (balance < amount) {
				throw new lessBalanceException();
			} else {
				return true;
			}
		}
	}

	// to set transactions

	public String setTrans(long actNum) throws accountNotFoundException {

		try {
			res = dao.checkAccount(actNum);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e);
		}
		String s;

		if (bank == null) {
			throw new accountNotFoundException();
		} else {
			s = bank.getTrans();
		}
		return s;
	}

	@Override
	public void setTransactions(BankTransaction trans) throws ClassNotFoundException, SQLException {

		dao.setTransactions(trans);
	}

	@Override
	public BankTransaction getTransactions(long actNum) throws ClassNotFoundException, SQLException {
		BankTransaction trans = new BankTransaction();
		trans = dao.getTransactions(actNum);
		return trans;
	}
}
