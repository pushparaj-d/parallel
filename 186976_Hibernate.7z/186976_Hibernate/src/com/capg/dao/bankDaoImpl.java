package com.capg.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.capg.entity.bankEntity;
import com.capg.entity.transactionEntity;

 


public class bankDaoImpl implements bankDao{

	EntityManager entity=UtilJava.getEntityManager();
	@Override
	
	
	
	
	public bankEntity getAccountById(int id) {
		bankEntity bank = entity.find(bankEntity.class, id);
		return bank;
	}

	@Override
	public void CreateAccount(bankEntity bank) {
		entity.persist(bank);
		
	}

	@Override
	public void ShowBalance(bankEntity bank) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Deposit(bankEntity bank) {
	entity.merge(bank);
		
	}

	@Override
	public void Withdraw(bankEntity bank) {
		entity.merge(bank);
		
	}
 
	public void PrintTransactions(int id) {
		Query q= entity.createQuery("select t from TransactionDetails t where accId=:tid");
		q.setParameter("tid", id);
		List<transactionEntity> l=q.getResultList();
		System.out.println("TransactionId		Account Id		TrasactionType		Amount"	);
		System.out.println("------------------------------------------------------------------");
		for(transactionEntity tdetails:l)
		{
		System.out.println(tdetails.getTransactionId()+"			"+tdetails.getAccId()+"			"+tdetails.getTransactionType()+"		"+tdetails.getAmount());
		}
	}

	@Override
	public void commitTransaction() {
		entity.getTransaction().commit();
		
	}

	@Override
	public void beginTransaction() {
		entity.getTransaction().begin();
		
	}

	public void addTransaction(transactionEntity trans) {
		 
		entity.persist(trans);
	}
	 
}
