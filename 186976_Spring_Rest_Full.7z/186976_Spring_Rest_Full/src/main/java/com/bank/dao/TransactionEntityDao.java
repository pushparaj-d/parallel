package com.bank.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.bank.entities.TransactionEntity;

public interface TransactionEntityDao extends JpaRepository<TransactionEntity, Integer> {
	
	@Query("from TransactionEntity where accNo=?1")
	List<TransactionEntity> printTransaction(Long accNo);

}
