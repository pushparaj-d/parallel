package com.cg.capstore.MerchantSignupRunner;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"pretty"},features= {"src/test/resources/MerchantSignupFeature/MerchantSignup.feature"},glue= {"/capstore/src/test/java/com/cg/capstore/MerchantSignupDefinition/MerchantSignupStepDefinition.java"})
public class MerchantSignupRunner {

}
