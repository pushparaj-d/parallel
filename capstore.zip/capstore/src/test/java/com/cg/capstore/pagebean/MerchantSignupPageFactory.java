package com.cg.capstore.pagebean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class MerchantSignupPageFactory {

	WebDriver driver;
	@FindBy(how=How.NAME,using="firstName")
	@CacheLookup
	WebElement firstName;
	@FindBy(how=How.NAME,using="lastName")
	@CacheLookup
	WebElement lastName;
	@FindBy(how=How.NAME,using="email")
	@CacheLookup
	WebElement emailid;
	@FindBy(how=How.NAME,using="storeName")
	@CacheLookup
	WebElement storeName;
	@FindBy(how=How.NAME,using="phone")
	@CacheLookup
	WebElement phoneNumber;
	@FindBy(how=How.NAME,using="password")
	@CacheLookup
	WebElement password;
	@FindBy(how=How.NAME,using="submit")
	@CacheLookup
	WebElement createButton;
	
	
	public MerchantSignupPageFactory(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	public WebDriver getDriver() {
		return driver;
	}
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	public WebElement getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public WebElement getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}
	public WebElement getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid.sendKeys(emailid);
	}
	public WebElement getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName.sendKeys(storeName);
	}
	public WebElement getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber.sendKeys(phoneNumber);
	}
	public WebElement getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password.sendKeys(password);
	}
	public WebElement getCreateButton() {
		return createButton;
	}
	public void setCreateButton() {
		this.createButton.click();
	}
	
}
