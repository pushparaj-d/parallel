package com.cg.capstore.MerchantSignupDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.capstore.pagebean.MerchantSignupPageFactory;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class MerchantSignupStepDefinition {
	
	private WebDriver driver;
	private MerchantSignupPageFactory factory;
	//Loading Driver using cucumber hook
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","Driver/chromedriver.exe");
		driver= new ChromeDriver();
	}

	@Given("^User is on 'Mercahnt signup form'$")
	public void user_is_on_Mercahnt_signup_form() throws Throwable {
	   driver.get("C:\\Users\\pushpd\\BDD\\capstore\\HTML\\merchantsignup.html");
	   factory=new MerchantSignupPageFactory(driver);
	}

	@When("^User enters invalid FirstName$")
	public void user_enters_invalid_FirstName() throws Throwable {
	   factory.setFirstName("");
	   factory.setCreateButton();
	   Thread.sleep(2000);
	   driver.close();
	}

	@Then("^Display 'Please enter a name'$")
	public void display_Please_enter_a_name() throws Throwable {
	   String expectedMessage="Please enter a name";
	   String actualMessage=driver.switchTo().alert().getText();
	   Assert.assertEquals(expectedMessage, actualMessage);
	   driver.switchTo().alert().accept();
	   Thread.sleep(2000);
	   driver.close();
	}

	@When("^User enters invalid LastsName$")
	public void user_enters_invalid_LastsName() throws Throwable {
	  factory.setFirstName("Shakthivel");
	  factory.setLastName("");
	  Thread.sleep(2000);
	  factory.setCreateButton();
	}

	@Then("^Display 'Please enter a lastName'$")
	public void display_Please_enter_a_lastName() throws Throwable {
		String expectedMessage="Please enter a lastName";
		   String actualMessage=driver.switchTo().alert().getText();
		   Assert.assertEquals(expectedMessage, actualMessage);
		   driver.switchTo().alert().accept();
		   Thread.sleep(2000);
		   driver.close();
	}
	
	@When("^User enters invalid Email$")
	public void user_enters_invalid_Email() throws Throwable {
	    factory.setFirstName("Shakthivel");
	    factory.setLastName("Kumaresan");
	    factory.setEmailid("");
	    Thread.sleep(2000);
	    factory.setCreateButton();
	}

	@Then("^Display 'Please enter Email ID'$")
	public void display_Please_enter_Email_ID() throws Throwable {
		String expectedMessage="Please Enter Email ID";
		   String actualMessage=driver.switchTo().alert().getText();
		   Assert.assertEquals(expectedMessage, actualMessage);
		   driver.switchTo().alert().accept();
		   Thread.sleep(2000);
		   driver.close();
	}

	@When("^User enters invalid StoreName$")
	public void user_enters_invalid_StoreName() throws Throwable {
		 factory.setFirstName("Shakthivel");
		    factory.setLastName("Kumaresan");
		    factory.setEmailid("shakthivel@gmail.com");
		    factory.setPhoneNumber("9876543210");
		    factory.setStoreName("");
		    Thread.sleep(2000);
		    factory.setCreateButton();
	}

	@Then("^Display 'Please enter StoreName'$")
	public void display_Please_enter_StoreName() throws Throwable {
		String expectedMessage="Please Enter Store name";
		   String actualMessage=driver.switchTo().alert().getText();
		   Assert.assertEquals(expectedMessage, actualMessage);
		   driver.switchTo().alert().accept();
		   Thread.sleep(2000);
		   driver.close();
	}

	@When("^User enters invalid password$")
	public void user_enters_invalid_password() throws Throwable {
		factory.setFirstName("Shakthivel");
	    factory.setLastName("Kumaresan");
	    factory.setEmailid("shakthivel@gmail.com");
	    factory.setPhoneNumber("9876543210");
	    factory.setStoreName("lakshmi stores");
	    factory.setPassword("");
	    Thread.sleep(2000);
	    driver.close();
	}

	@Then("^Display 'Please enter password'$")
	public void display_Please_enter_password() throws Throwable {
		String expectedMessage="Please Enter a Password";
		   String actualMessage=driver.switchTo().alert().getText();
		   Assert.assertEquals(expectedMessage, actualMessage);
		   driver.switchTo().alert().accept();
		   Thread.sleep(2000);
		   driver.close();
	}

	@When("^User enters a lowercase for password as firstletter$")
	public void user_enters_a_lowercase_for_password_as_firstletter() throws Throwable {
		factory.setFirstName("Shakthivel");
	    factory.setLastName("Kumaresan");
	    factory.setEmailid("shakthivel@gmail.com");
	    factory.setPhoneNumber("9876543210");
	    factory.setStoreName("lakshmi stores");
	    factory.setPassword("pass1234");
	    Thread.sleep(2000);
	    factory.setCreateButton();
	}

	@Then("^Display 'Please enter valid password'$")
	public void display_Please_enter_valid_password() throws Throwable {
		String expectedMessage="Password does not meet the requirement";
		   String actualMessage=driver.switchTo().alert().getText();
		   Assert.assertEquals(expectedMessage, actualMessage);
		   driver.switchTo().alert().accept();
		   Thread.sleep(2000);
		   driver.close();
	}

	@When("^User password less than (\\d+) characters$")
	public void user_password_less_than_characters(int arg1) throws Throwable {
		factory.setFirstName("Shakthivel");
	    factory.setLastName("Kumaresan");
	    factory.setEmailid("shakthivel@gmail.com");
	    factory.setPhoneNumber("9876543210");
	    factory.setStoreName("lakshmi stores");
	    factory.setPassword("pass12345");
	    Thread.sleep(2000);
	    factory.setCreateButton();
	}
	@Then("^Display 'password should be length of (\\d+)'$")
	public void display_password_should_be_length_of(int arg1) throws Throwable {
		String expectedMessage="Password must be atleast 8 characters";
		   String actualMessage=driver.switchTo().alert().getText();
		   Assert.assertEquals(expectedMessage, actualMessage);
		   driver.switchTo().alert().accept();
		   Thread.sleep(2000);
		   driver.close();
	}

}
