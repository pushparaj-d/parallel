package com.capg.client;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capg.entity.bankEntity;
import com.capg.entity.transactionEntity;
import com.capg.service.bankService;
public class Client {
	
	 
		public static void main(String[] args) {
			
		Scanner scan  = new Scanner(System.in);      
           ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
   		bankService bankService =  context.getBean("bankService",bankService.class);
	   String str;
			int c,balance;
			String choice,name,password,phoneNo;
			
			while(true)
			{
	

				System.out.println("\n\n<<<<<<<<<<<<<<<<<<<<.............Welcome to MAY Bank Application.............>>>>>>>>>>>>>>>>>>");
				
				System.out.println("\n\nChoose your option: \n 1. Create Account\n 2. Show Balance\n 3. Deposit amount\n 4. WithDraw amount\n 5. Fund Transfer\n 6. Print Transaction\n 7. Exit");
	          	
					System.out.println("Enter Your choice : ");
				 str = scan.next();
				
				
				if(str.matches("[a-z]*")||str.matches("[A-Z]*"))
				{	     
					System.out.println("Invalid Choice!!!");
					main(null);
	            }
				
				
				switch (str) {
				case "1":


					System.out.println("Welcome to MAY Bank");


					do
					{
						System.out.println("Enter your name");
						name = scan.next();
						c =bankService.nameValidate(name);
					}
					while(c!=1);
					
					
					do
					{
						System.out.println("Enter your mobile number");
						phoneNo = scan.next();
						c = bankService.mobNoValidate(phoneNo);
					}
					while(c!=1);
	                 
					long phone1 = Long.parseLong(phoneNo);
					long accountNo = phone1 + 1;

					do
					{
						System.out.println("Create your password");
						password = scan.next();
						c = bankService.passwordValidate(password);
					}
					while(c!=1);

					do
					{
						System.out.println("Enter the amount");
						balance = scan.nextInt();
						c = bankService.checkBalance(balance);
					}
					while(c!=1);
					
					boolean result =  bankService.createAccount(name,phoneNo,password,accountNo,balance);
					if(result)
					{
						System.out.println("Your Account has been created successfully: "+accountNo);
					}
					break;

				case "2":

					System.out.println("Enter your account number");
					accountNo = scan.nextLong();
					System.out.println("Enter your password");
					password = scan.next();
					boolean b1= bankService.validateAccount(accountNo,password);
					if(b1)
					{
							balance = bankService.showBalance(accountNo);
							if(balance!=0)
							{
								System.out.println("Your account balance is "+balance);
							}
							else
							{
								System.out.println("Problem ");
							}
					}
					else
					{
						System.out.println("wrong details");
					}

					break;
				case "3":
					System.out.println("Enter your account number");
					accountNo = scan.nextLong();
					System.out.println("Enter your password");
					password = scan.next();
					boolean b= bankService.validateAccount(accountNo,password);
					if(b)
					{
						System.out.println("Enter the amount to be deposited");
						int deposit = scan.nextInt();
						balance = bankService.depositAmount(accountNo,deposit);
						System.out.println("Amount has been deposited to your account");
						System.out.println("your new balance is "+balance);
					}
					else
					{
						System.out.println("wrong details");
					}
					break;
				case "4":

					System.out.println("Enter your account number");
					accountNo = scan.nextLong();
					System.out.println("Enter your password");
					password = scan.next();
					b= bankService.validateAccount(accountNo,password);
					if(b)
					{
						balance = bankService.showBalance(accountNo);
						System.out.println("Your current balance is "+balance);
						System.out.println("Enter the amount to be withdraw");
						int withdraw = scan.nextInt();
							balance = bankService.withdrawAmount(accountNo,withdraw);
							if(balance>=0)
							{
								System.out.println("Amount has been withdrawan from your account...");
						
								System.out.println("Your new account balance is "+balance+"\n");
							}
							else
							{
                                 System.out.println("Insufficient funds");
							}
						}
						
					
					else
					{
				               System.out.println("wrong credential");
					}
					break;
					
				case "5":

					System.out.println("Enter the senders account number");
					accountNo = scan.nextLong();
					System.out.println("Enter your password");
					password = scan.next();
					b= bankService.validateAccount(accountNo,password);
					if(b)
					{
						System.out.println("\nEnter the recivers account transfer");
						long  accno = scan.nextLong();
						System.out.println("Enter the amount you want to transfer");
						int amount = scan.nextInt();
						boolean transfer = bankService.fundTransfer(accountNo, accno, amount);
						if(transfer)
						{
							System.out.println(amount+ "amount has been transfered successfully...");
						}
						else
						{
						  System.out.println("Problem in transaction");
						}
					}
					else
					{
						System.out.println("invalid account details");
					}

					break;
				case "6":
					System.out.println("Enter your account number");
					accountNo = scan.nextLong();
					System.out.println("Enter your password");
					password = scan.next();
					b= bankService.validateAccount(accountNo,password);
					if(b)
					{
	                    List<transactionEntity> trans=bankService.getTransaction(accountNo);

						System.out.println("----------Transaction Statement----------\n");

						for(transactionEntity tran:trans)
						{
							System.out.println(tran);
						}

					}
					else 
					{
						System.out.println("Account not exist!");
					}
					break;
					
				case "7": 
					 System.out.println("<<<<<<<<<<<<<<<<<<<<.............Thank you for using our Bank Services.............>>>>>>>>>>>>>>>>>>");
					System.exit(0);
				}

			}
	
	}

}
