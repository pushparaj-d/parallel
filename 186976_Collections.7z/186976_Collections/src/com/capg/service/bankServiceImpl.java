package com.capg.service;

import com.capg.exception.accountAlreadyExistsException;
import com.capg.exception.accountNotFoundException;
import com.capg.exception.lessBalanceException;

public interface bankServiceImpl {


	public boolean createAccount(String name, String add, long accNo, String phone, int pin, int bal)
			throws accountAlreadyExistsException;

	public int showBalance(long accNo) throws accountNotFoundException;

	public int deposit(long accNo, int deposit_amount) throws accountNotFoundException;

	public int withdraw(long accNo, int withdraw_amount) throws accountNotFoundException, lessBalanceException;

	public boolean transferfund(long accNo, long accNo1, int transfer_amount)
			throws accountNotFoundException, lessBalanceException;

	public boolean validateBalance(long accNo, int amount) throws lessBalanceException;

	public String setTrans(long accNo) throws accountNotFoundException;

}
