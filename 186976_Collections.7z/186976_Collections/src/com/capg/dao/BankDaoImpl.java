package com.capg.dao;

import com.capg.bean.bankBean;

public interface BankDaoImpl {

	public bankBean checkAccount(long accNo);

	public void setData(long accNo, bankBean bean);

}
