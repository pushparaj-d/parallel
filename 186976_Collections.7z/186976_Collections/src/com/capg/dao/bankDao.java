package com.capg.dao;
import java.util.HashMap;

import com.capg.bean.bankBean;



public class bankDao implements BankDaoImpl {


		HashMap hMap;

		public bankDao() {

			hMap = new HashMap();
		}

		// bean class object

		bankBean bean = new bankBean();

		// to check account already exists or not

		public bankBean checkAccount(long accNo) {

			if (hMap.containsKey(accNo)) {

				bean = (bankBean) hMap.get(accNo);
				return bean;

			} else

				return null;
		}

		// to put the data into the map

		public void setData(long accNo, bankBean bean) {

			hMap.put(accNo, bean);
		}

	}


