package com.capg.ui;

import java.util.Scanner;

import com.capg.exception.accountAlreadyExistsException;
import com.capg.exception.accountNotFoundException;
import com.capg.exception.lessBalanceException;
import com.capg.service.bankService;
import com.capg.service.bankServiceImpl;

public class bankMain {

	static Scanner scan = new Scanner(System.in);

	public static int menu() {
		
		// displaying menu

		System.out.println("\n\n<<<<<<<<<<<<<<<<<<<<.............Welcome to MAY Bank Application.............>>>>>>>>>>>>>>>>>>");
				
				System.out.println("\n\nChoose your option: \n 1. Create Account\n 2. Show Balance\n 3. Deposit amount\n 4. WithDraw amount\n 5. Fund Transfer\n 6. Print Transaction\n 7. Exit");
				
				System.out.println("Enter Your choice : ");
				int choice = scan.nextInt();

				String s = Integer.toString(choice);
				String pattern = ("[0-7]{1}");
				while (!s.matches(pattern)) {
					System.out.println("Invalid Chice");
					System.out.println("Enter Choice");
					choice = scan.nextInt();
				}
				return choice;
			}
	public static void main(String[] args) throws accountNotFoundException {

		// variables used

		long actNum, actNum1;
		int withdraw_amount, deposit_amount = 0, transfer_amount = 0;
		int pin;
		int amount = 0;
		int balance = 0;
		boolean res = false;
		String cont = "yes";

		bankServiceImpl service = new bankService();
		
		while (cont.equalsIgnoreCase("yes")) {
			switch (menu()) {

			// Creating an account

			case 1:

				System.out.println("Enter the name");
				String name = scan.nextLine();
				name += scan.nextLine();

				String regexUserName = "[A-Za-z\\s]+$";
				while (!name.matches(regexUserName)) {

					System.out.println("Please enter a valid name..");
					System.out.println("Enter the name");
					name = scan.next();
				}

				System.out.println("Enter the address ");
				String add = scan.next();
				add += scan.nextLine();

				while (!add.matches(regexUserName)) {
					System.out.println("Please enter a valid address..");
					System.out.println("Enter the address ");
					add = scan.nextLine();

				}

				System.out.println("Enter the contact number");
				String phone = scan.next();
				String phone_format = ("[6-9][0-9]{9}");

				while (!phone.matches(phone_format)) {
					while (phone.length() < 10 || phone.length() > 10) {

						System.out.println("Contact number must be 10 digits");
						System.out.println("Enter the Contact number");
						phone = scan.next();
					}
					System.out.println("Contact number should start from 6");
					System.out.println("Enter the Contact number");
					phone = scan.next();
				}

				actNum = Long.parseLong(phone) - 10000;

				System.out.println("Enter the Pin");
				pin = scan.nextInt();

				while (String.valueOf(pin).length() < 4 || String.valueOf(pin).length() > 4) {

					System.out.println("Pin number should be of 4 digits");
					System.out.println("Enter Pin");
					pin = scan.nextInt();
				}

				System.out.println("Enter Balance");
				int bal = scan.nextInt();

				while (bal < 1000) {
					System.out.println("Minimum Balance should be 1000");
					System.out.println("Enter the Balance");
					bal = scan.nextInt();

				}
				try {
					res = service.createAccount(name, add, actNum, phone, pin, bal);
				} catch (accountAlreadyExistsException e) {

					System.out.println(e);
					break;
				}

				if (res == true) {
					System.out.println("Your Account has been Created Successfully !!!");
					System.out.println("Your Account Number is: " + actNum);

				} else {

					System.out.println("Your account creation is not processed...");
				}

				break;

				//displaying balance
				
			case 2:

				System.out.println("Enter the account number");
				actNum = scan.nextLong();

				try {
					balance = service.showBalance(actNum);
				} catch (accountNotFoundException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Your Account Balance is :" + balance);

				break;

				// depositing amount to account

			case 3:

				System.out.println("Enter the account number");
				actNum = scan.nextLong();

				System.out.println("Enter the amount to be deposited");
				deposit_amount = scan.nextInt();

				try {
					amount = service.deposit(actNum, deposit_amount);

					balance = service.showBalance(actNum);
				}

				catch (accountNotFoundException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount has been deposited to your account: " + deposit_amount);
				System.out.println("Your updated balance is: " + balance);

				break;

				// withdrawing amount from account

			case 4:

				System.out.println("Enter the account number");
				actNum = scan.nextLong();

				System.out.println("Enter the amount to withdraw");
				withdraw_amount = scan.nextInt();

				try {
					amount = service.withdraw(actNum, withdraw_amount);
					res = service.validateBalance(actNum, withdraw_amount);
					balance = service.showBalance(actNum);

				} catch (accountNotFoundException e) {

					System.out.println(e);
					break;

				} catch (lessBalanceException e) {

					System.out.println(e);
					break;
				}

				System.out.println("The amount you withdrawn is: " + withdraw_amount);
				System.out.println("Your updated balance is: " + balance);

				break;

				//amount transfering from one account to another account
				
				
			case 5:

				int senders_balance = 0;
				int recievers_balance = 0;

				System.out.println("Enter the senders account number");
				actNum = scan.nextLong();

				System.out.println("Enter the receivers account number");
				actNum1 = scan.nextLong();

				System.out.println("Enter the amount to transfer");
				transfer_amount = scan.nextInt();

				try {
					res = service.validateBalance(actNum, transfer_amount);
					res = service.transferfund(actNum, actNum1, transfer_amount);

					senders_balance = service.showBalance(actNum);
					recievers_balance = service.showBalance(actNum1);

				} catch (accountNotFoundException e) {

					System.out.println(e);
					break;
				} catch (lessBalanceException e) {
					System.out.println(e);
					break;
				}

				System.out.println("The amount has been transferred Successfully");
				System.out.println("The updated balance for Account " + actNum + " : " + senders_balance);
				System.out.println("The updated balance for Account " + actNum1 + " : " + recievers_balance);

				break;

				// displaying the transactions of particular account
				
			case 6:

				String str = null;
				System.out.println("Enter the account number");
				actNum = scan.nextLong();
				System.out.println("Enter your pin");
				pin = scan.nextInt();
				try {
					str = service.setTrans(actNum);
					System.out.println(str);
				} catch (accountNotFoundException e) {
					System.out.println(e);
					
				}
				break;

				// exit
				
			case 7:
				System.out.println("<<<<<<<<<<<<<<<<<<<<.............Thank you for banking with us.............>>>>>>>>>>>>>>>>>>");
				System.exit(0);
				cont = "no";
				break;
				
				//when user enters invalid choice
				
			default:
				System.out.println("Please Enter choice between 1 - 7 ");
				menu();

			}
		}

	}

	
}
