package com.capg.exception;

public class accountNotFoundException extends Exception {

	public accountNotFoundException() {

	}

	public String toString() {

		return "Account Not Found . \nPlease Enter a valid account number!!!";
	}

}
