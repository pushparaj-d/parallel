package com.capg.exception;

	public class minBalanceException extends Exception {

		@Override
		public String toString() {

			return "Minimum Balance should be 1000";
		}

		public minBalanceException() {

		}
	}

