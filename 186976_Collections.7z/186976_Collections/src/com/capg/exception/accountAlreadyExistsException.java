package com.capg.exception;

public class accountAlreadyExistsException extends Exception {

	public accountAlreadyExistsException() {

	}

	@Override
	public String toString() {
		return "Account Already Exists";
	}

}
