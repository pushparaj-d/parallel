package com.capg.exception;

public class lessBalanceException extends Exception {

	public lessBalanceException() {

	}

	@Override
	public String toString() {
		return "Low Balance \nCannot Operation";
	}

}
